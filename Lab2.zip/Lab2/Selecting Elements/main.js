//Selecting Elements
//1.)  find two different ways to target the first section element on the page. Use console.log to check. Put a comment with the word faster by the method that targets the element more quickly and efficently. 
let firstWay = document.querySelector('section');
var secondWay = document.getElementById('section');
console.log(firstWay);
console.log(secondWay);

//2.)  Target the footer element. Use console.log to check 
let footerElement1 = document.querySelector('footer');
console.log(footerElement1);

//3.)  Target all elements with the class or orange and change the text in these elements orange 
var orange = document.getElementsByClassName('orange');
for(let c=0; c<orange.length; c++){
    orange[c].style.color = 'orange';
}

//5.) Find two ways to target the second section element 
var targetWay1 = document.querySelectorAll('section')[1];
let targetWay2 = document.getElementsByTagName('section')[1];

//4.) Target all section elements and console log
var secElement = document.querySelectorAll('section');
console.log(secElement);

