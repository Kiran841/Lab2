//1.) Using ol as your starting element, target the first li element 
var ol = document.querySelector('ol');//here ol is starting element

let li = ol.firstElementChild;


//2.) using main as your starting element, what is the last child? console.log to check it out 
var mainAsStartingElement = document.querySelector('main');

let lastChild = mainAsStartingElement.lastChild;

console.log(mainAsStartingElement, lastChild);


//3.) using html as your starting element, what is the last Element child? Console.log to check it out. 
var htmlAsStartingElement = document.querySelector('html');

let childZ = htmlAsStartingElement.lastElementChild;

console.log(htmlAsStartingElement, childZ); 


//4.) using the second li element as your starting element, target the next li element and change the colour to purple. 
var element2 = document.getElementsByTagName('li')[1];

let element3 = element2.nextElementSibling;

while(z<element3.length)
{
    var z = 0;
    element3[z].style.color = 'purple';
    z++;
}

