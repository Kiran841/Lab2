//1.) Add a new paragraph to the page
var main = document.querySelector('main');
let newPara1 = document.createElement('p');
main.appendChild(newPara1);
newPara1.textContent = 'My name is Kiran. I liked the concept of DOM.';

//3.) Change the src attribute in the image element to 'cat2.jpg'
let c = document.getElementsByTagName("img")[0]
c.setAttribute("src", "assets/cat2.jpg");

//4.) Remove the footer element 
var f = document.querySelectorAll('p')[3];
var parent = document.querySelector('footer');
parent.removeChild(f);

//5.) Add an h3 into the header 
var h = document.querySelector('header');
var h3 = document.createElement('h3');
h.appendChild(h3);
h3.textContent = 'Cats are cute';